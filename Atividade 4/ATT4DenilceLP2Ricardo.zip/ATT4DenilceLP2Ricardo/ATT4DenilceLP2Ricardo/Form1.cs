﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATT4DenilceLP2Ricardo
{
    public partial class Form1 : Form
    {
        double Peso, Altura, IMC;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtPeso.Text, out Peso))
            {
                MessageBox.Show("Letras não são válidas");
            }else if(Peso == 0)
            {
                MessageBox.Show("Por favor digite um número maior que 0");
                txtPeso.Focus();
            } 
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out Altura))
            {
                MessageBox.Show("Letras não são válidas");
            }
            else if (Altura == 0)
            {
                MessageBox.Show("Por favor digite um número maior que 0");
                
            }
            txtAltura.Focus();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            IMC = Math.Round(Peso / (Math.Pow(Altura, 2)), 2);
                txtIMC.Text = IMC.ToString();

            if (IMC < 18.5)
            {
                txtClass.Text = "Abaixo do Peso";
            }
            else if (IMC > 18.5 && IMC < 25)
            {
                txtClass.Text = "Saudável";
            }
            else if (IMC >= 25 && IMC < 30)
            {
                txtClass.Text = "Sobrepeso";
            }
            else if (IMC >= 30 && IMC < 35)
            {
                txtClass.Text = "Obesidade Grau 1";
            }
            else if (IMC >= 35 && IMC < 40)
            {
                txtClass.Text = "Obesidade Grau 2 (severa)";
            }
            else if (IMC >= 40)
            {
                txtClass.Text = "Obesidade Grau 3 (mórbida)";
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Text = "";
            txtPeso.Text = "";
            txtIMC.Text = "";
            txtClass.Text = "";

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
