﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double dnomeFuncionario; // ! para ser só double

            if (Double.TryParse(txtNomeFunc.Text, out dnomeFuncionario))//Se não for string
            {
                MessageBox.Show("Este nome de funcionário é inválido, digite o nome novamente!");
                txtNomeFunc.Focus();
            }
            else if (txtNomeFunc.Text == "")
            {
                MessageBox.Show("Nome do funcionário está vazio, digite o nome!");
                txtNomeFunc.Focus();
            }

            else//Outro componente
            {
                double matricula;

                if (!Double.TryParse(txtMatri.Text, out matricula))
                {
                    MessageBox.Show("Valor invalido");
                    txtMatri.Focus();
                }

                else//Outro componente
                {
                    double producao;

                    if (!Double.TryParse(txtProd.Text, out producao))
                    {
                        MessageBox.Show("Valor invalido");
                        txtProd.Focus();
                    }
                    else if (producao <= 0)
                    {
                        MessageBox.Show("Valor tem que ser maior que zero");
                        txtProd.Focus();
                    }

                    else//Outro componente
                    {
                        double gratificao;

                        if (!Double.TryParse(txtGrati.Text, out gratificao))
                        {
                            MessageBox.Show("Valor invalido");
                            txtGrati.Focus();
                        }
                        else if (gratificao < 0)
                        {
                            MessageBox.Show("Valor tem que ser maior que zero");
                            txtGrati.Focus();
                        }

                        else//Outro componente
                        {
                            double cargo;

                            if (Double.TryParse(cbxCargo.Text, out cargo))
                            {
                                MessageBox.Show("Valor invalido");
                                cbxCargo.Focus();
                            }

                            else//Outro componente
                            {
                                double salario;

                                if (Double.TryParse(txtSalario.Text, out salario))
                                {
                                    MessageBox.Show("Valor invalido");
                                    txtSalario.Focus();
                                }

                                else// Se tudo deu certo
                                {
                                    double A;
                                    double B;
                                    double C;
                                    double D;

                                    string mensagem;

                                    // Criei
                                    if (cbxCargo.Text == "Setor 1")
                                        A = 1000;
                                    else if (cbxCargo.Text == "Setor 2")
                                        A = 2000;
                                    else if (cbxCargo.Text == "Setor 3")
                                        A = 3000;
                                    else if (cbxCargo.Text == "Setor 4")
                                        A = 4000;
                                    else if (cbxCargo.Text == "Setor 5")
                                        A = 5000;
                                    else if (cbxCargo.Text == "Setor 6")
                                        A = 6000;
                                    else if (cbxCargo.Text == "Setor 7")
                                        A = 7000;
                                    else if (cbxCargo.Text == "Setor 8")
                                        A = 8000;
                                    else
                                        A = 0;

                                    if (producao >= 100)
                                        B = 1;
                                    else
                                        B = 0;

                                    if (producao >= 120)
                                        C = 1;
                                    else
                                        C = 0;

                                    if (producao >= 150)
                                        D = 1;
                                    else
                                        D = 0;

                                    salario = A + A * ((0.05 * B) + (0.10 * C) + (0.10 * D)) + gratificao;


                                    if (salario < 7000)
                                        salario = salario + 0;// Não muda
                                    else
                                    {
                                        if (salario >= 7000 && producao >= 150 && gratificao > 0)
                                            salario = salario + 0;// Não muda
                                        else
                                            salario = 7000;
                                    }

                                    mensagem = salario.ToString("N2");

                                    MessageBox.Show(mensagem);

                                }
                            }
                        }    
                    }    
                }    
            }
        }
    }
}
