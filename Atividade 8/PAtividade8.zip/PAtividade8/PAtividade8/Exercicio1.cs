﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnNumEspacBran_Click(object sender, EventArgs e)
        {
            int i;
            int qtdeEspacBran;
            string mensagem;
            char posicao;

            qtdeEspacBran = 0;

            for (i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                posicao = rchtxtFrase.Text[i];
                if (Char.IsWhiteSpace(posicao))
                    qtdeEspacBran = qtdeEspacBran + 1;
            }
            mensagem = qtdeEspacBran.ToString();
            MessageBox.Show(mensagem);
        }

        private void btnNumLetraR_Click(object sender, EventArgs e)
        {
            int i;
            int qtdeLetraR;
            string mensagem;
            char posicao;

            qtdeLetraR = 0;

            for (i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                posicao = rchtxtFrase.Text[i];
                if (posicao == 'R' || posicao == 'r')
                    qtdeLetraR = qtdeLetraR + 1;
            }
            mensagem = qtdeLetraR.ToString();
            MessageBox.Show(mensagem);
        }

        private void btnNumParLetras_Click(object sender, EventArgs e)
        {
            int i;
            int qtdeParLetras;
            string mensagem;
            char posicao;
            char posicaoAnteri;
            string auxiliar = rchtxtFrase.Text.Replace(" ", "");

            i = 0;
            qtdeParLetras = 0;

            while (i < auxiliar.Length)
            {
                posicao = auxiliar[i];

                if (i == 0)
                    posicaoAnteri = auxiliar[i];
                else
                {
                    posicaoAnteri = auxiliar[i - 1];

                    if (posicao == posicaoAnteri)
                        qtdeParLetras = qtdeParLetras + 1;
                }
               
                i++;
            }
            mensagem = qtdeParLetras.ToString();
            MessageBox.Show(mensagem);
        }
    }
}
