﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnCalcularH_Click(object sender, EventArgs e)
        {
            int N;
            double H;
            int i;
            string mensagem;

            if (!int.TryParse(txtNumN.Text, out N))
                MessageBox.Show("Valor invalido");
            else
            {
                i = 2;
                H = 1;

                if (N > 0)
                {
                    while (i <= N)
                    {
                        H = H + (1.00 / i);
                        i++;
                    }
                }
                else
                {
                    MessageBox.Show("Número N tem que ser maior que zero");
                    txtNumN.Focus();

                }
                mensagem = H.ToString("N2");
                MessageBox.Show(mensagem);
            }
        }
    }
}
