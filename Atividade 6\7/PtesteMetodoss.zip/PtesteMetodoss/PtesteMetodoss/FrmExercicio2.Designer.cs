﻿namespace PtesteMetodoss
{
    partial class FrmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt1 = new System.Windows.Forms.TextBox();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.lblPalavra1 = new System.Windows.Forms.Label();
            this.lblPalavra2 = new System.Windows.Forms.Label();
            this.btnteste = new System.Windows.Forms.Button();
            this.btnTxt2 = new System.Windows.Forms.Button();
            this.btnAsteriscos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(135, 28);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(211, 20);
            this.txt1.TabIndex = 0;
            // 
            // txt2
            // 
            this.txt2.Location = new System.Drawing.Point(135, 72);
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(211, 20);
            this.txt2.TabIndex = 1;
            // 
            // lblPalavra1
            // 
            this.lblPalavra1.AutoSize = true;
            this.lblPalavra1.Location = new System.Drawing.Point(33, 28);
            this.lblPalavra1.Name = "lblPalavra1";
            this.lblPalavra1.Size = new System.Drawing.Size(52, 13);
            this.lblPalavra1.TabIndex = 2;
            this.lblPalavra1.Text = "Palavra 1";
            // 
            // lblPalavra2
            // 
            this.lblPalavra2.AutoSize = true;
            this.lblPalavra2.Location = new System.Drawing.Point(33, 72);
            this.lblPalavra2.Name = "lblPalavra2";
            this.lblPalavra2.Size = new System.Drawing.Size(52, 13);
            this.lblPalavra2.TabIndex = 3;
            this.lblPalavra2.Text = "Palavra 2";
            // 
            // btnteste
            // 
            this.btnteste.Location = new System.Drawing.Point(13, 147);
            this.btnteste.Name = "btnteste";
            this.btnteste.Size = new System.Drawing.Size(97, 54);
            this.btnteste.TabIndex = 4;
            this.btnteste.Text = "Testar Iguais";
            this.btnteste.UseVisualStyleBackColor = true;
            this.btnteste.Click += new System.EventHandler(this.btnteste_Click);
            // 
            // btnTxt2
            // 
            this.btnTxt2.Location = new System.Drawing.Point(160, 147);
            this.btnTxt2.Name = "btnTxt2";
            this.btnTxt2.Size = new System.Drawing.Size(96, 54);
            this.btnTxt2.TabIndex = 5;
            this.btnTxt2.Text = "Inserir Texto 1 no Texto 2";
            this.btnTxt2.UseVisualStyleBackColor = true;
            this.btnTxt2.Click += new System.EventHandler(this.btnTxt1_Click);
            // 
            // btnAsteriscos
            // 
            this.btnAsteriscos.Location = new System.Drawing.Point(307, 147);
            this.btnAsteriscos.Name = "btnAsteriscos";
            this.btnAsteriscos.Size = new System.Drawing.Size(108, 54);
            this.btnAsteriscos.TabIndex = 6;
            this.btnAsteriscos.Text = "Inserir Asteriscos  no Texto 1";
            this.btnAsteriscos.UseVisualStyleBackColor = true;
            this.btnAsteriscos.Click += new System.EventHandler(this.btnAsteriscos_Click);
            // 
            // FrmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(570, 289);
            this.Controls.Add(this.btnAsteriscos);
            this.Controls.Add(this.btnTxt2);
            this.Controls.Add(this.btnteste);
            this.Controls.Add(this.lblPalavra2);
            this.Controls.Add(this.lblPalavra1);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.txt1);
            this.Name = "FrmExercicio2";
            this.Text = "FrmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.TextBox txt2;
        private System.Windows.Forms.Label lblPalavra1;
        private System.Windows.Forms.Label lblPalavra2;
        private System.Windows.Forms.Button btnteste;
        private System.Windows.Forms.Button btnTxt2;
        private System.Windows.Forms.Button btnAsteriscos;
    }
}