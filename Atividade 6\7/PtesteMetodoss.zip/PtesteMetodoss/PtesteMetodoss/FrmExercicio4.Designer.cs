﻿namespace PtesteMetodoss
{
    partial class FrmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rhtxtfrase = new System.Windows.Forms.RichTextBox();
            this.btnqntnum = new System.Windows.Forms.Button();
            this.btnbranco = new System.Windows.Forms.Button();
            this.btnqntletra = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rhtxtfrase
            // 
            this.rhtxtfrase.Location = new System.Drawing.Point(314, 61);
            this.rhtxtfrase.Name = "rhtxtfrase";
            this.rhtxtfrase.Size = new System.Drawing.Size(334, 136);
            this.rhtxtfrase.TabIndex = 0;
            this.rhtxtfrase.Text = "";
            // 
            // btnqntnum
            // 
            this.btnqntnum.Location = new System.Drawing.Point(124, 315);
            this.btnqntnum.Name = "btnqntnum";
            this.btnqntnum.Size = new System.Drawing.Size(165, 64);
            this.btnqntnum.TabIndex = 1;
            this.btnqntnum.Text = "Quantidade de número";
            this.btnqntnum.UseVisualStyleBackColor = true;
            this.btnqntnum.Click += new System.EventHandler(this.btnqntnum_Click);
            // 
            // btnbranco
            // 
            this.btnbranco.Location = new System.Drawing.Point(392, 306);
            this.btnbranco.Name = "btnbranco";
            this.btnbranco.Size = new System.Drawing.Size(165, 64);
            this.btnbranco.TabIndex = 2;
            this.btnbranco.Text = "Primeiro Branco";
            this.btnbranco.UseVisualStyleBackColor = true;
            this.btnbranco.Click += new System.EventHandler(this.btnbranco_Click);
            // 
            // btnqntletra
            // 
            this.btnqntletra.Location = new System.Drawing.Point(686, 315);
            this.btnqntletra.Name = "btnqntletra";
            this.btnqntletra.Size = new System.Drawing.Size(165, 64);
            this.btnqntletra.TabIndex = 3;
            this.btnqntletra.Text = "Quantidade de letra";
            this.btnqntletra.UseVisualStyleBackColor = true;
            this.btnqntletra.Click += new System.EventHandler(this.btnqntletra_Click);
            // 
            // FrmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(970, 608);
            this.Controls.Add(this.btnqntletra);
            this.Controls.Add(this.btnbranco);
            this.Controls.Add(this.btnqntnum);
            this.Controls.Add(this.rhtxtfrase);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FrmExercicio4";
            this.Text = "FrmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rhtxtfrase;
        private System.Windows.Forms.Button btnqntnum;
        private System.Windows.Forms.Button btnbranco;
        private System.Windows.Forms.Button btnqntletra;
    }
}