﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Att3DenilceLP2RicardoGonc
{
    public partial class Form1 : Form
    {
        double LadoA, LadoB, LadoC;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtA.Text, out LadoA))
            {
                MessageBox.Show("Valor lado A " + "Invalido");
            }
            else
          if (LadoA == 0)
            {
                MessageBox.Show("Valor lado A não pode ser zero");
                txtA.Focus();
            }

        }

        private void txtB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtB.Text, out LadoB))
            {
                MessageBox.Show("Valor lado B " + "Invalido");
            }
            else
        if (LadoB == 0)
            {
                MessageBox.Show("Valor lado B não pode ser zero");
                txtB.Focus();
            }

        }

        private void txtC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtC.Text, out LadoC))
            {
                MessageBox.Show("Valor lado C " + "Invalido");
            }
            else
        if (LadoC == 0)
            {
                MessageBox.Show("Valor lado C não pode ser zero");
                txtC.Focus();
            }

        }

        private void Calcular_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtA.Text, out LadoA) && double.TryParse(txtB.Text, out LadoB) && double.TryParse(txtC.Text, out LadoC))
            {
                if (LadoA < (LadoB + LadoC) && LadoA > Math.Abs(LadoB - LadoC) && LadoB < (LadoA + LadoC) && LadoB > Math.Abs(LadoA - LadoC) && LadoC < (LadoA + LadoB) && LadoC > Math.Abs(LadoA - LadoB))
                {

                    if (LadoA == LadoB && LadoB == LadoC)
                        MessageBox.Show("Triangulo Equilatero");
                    else if (LadoA == LadoB || LadoA == LadoC || LadoB == LadoC)
                        MessageBox.Show("Triangulo Isosceles");
                    else if 
                        (LadoA != LadoB && LadoB != LadoC && LadoA != LadoC)
                        MessageBox.Show("Triangulo Escaleno");
                    //Professora, quando eu coloco apenas o else na validação do escaleno ele pede ;, como eu posso proceder para resolver tal erro?
                }
                else
                    MessageBox.Show("Os valores não formam um triângulo");
            }
        }

        private void Limpar_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
        }

        private void Close_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
