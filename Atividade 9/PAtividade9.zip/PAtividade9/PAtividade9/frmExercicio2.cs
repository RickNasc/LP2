﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade9
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnEntrada_Click(object sender, EventArgs e)
        {
            string auxiliar1;
            string auxiliar2;
            int[] vetor1 = new int[10];
            double[] vetor2 = new double[10];
            double[] vetor3 = new double[10];
            double varAcumul;
            string mensagem;

            varAcumul = 0;

            for (var x = 0; x < 10; x++)
            {
                auxiliar1 = Interaction.InputBox("Digite a quantidade do produto " + (x + 1), "Entrada de Dados");
                if (!int.TryParse(auxiliar1, out vetor1[x]))
                {
                    MessageBox.Show("Valor inválido");
                    x -= 1;
                    continue;
                }
                auxiliar2 = Interaction.InputBox("Digite o preço do produto " + (x + 1), "Entrada de Dados");
                if (!double.TryParse(auxiliar2, out vetor2[x]))
                {
                    MessageBox.Show("Valor inválido");
                    x -= 1;
                    continue;
                }
            }
            auxiliar1 = "";
            auxiliar2 = "";

            for (var x = 0; x < 10; x++)// Cálculo
            {
                vetor3[x] = vetor1[x] * vetor2[x];
                varAcumul = varAcumul + vetor3[x];
            }

            mensagem = varAcumul.ToString("N2");

            foreach (int i in vetor1)
                auxiliar1 = auxiliar1 + "\n" + i;
            foreach (int i in vetor2)
                auxiliar2 = auxiliar2 + "\n" + i;

            MessageBox.Show(mensagem,"Faturamento mensal: R$");
        }
    }
}
