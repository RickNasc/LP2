﻿namespace PAtividade9
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExclua = new System.Windows.Forms.Button();
            this.lblInserir = new System.Windows.Forms.Label();
            this.lblInfo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnExclua
            // 
            this.btnExclua.Location = new System.Drawing.Point(280, 117);
            this.btnExclua.Name = "btnExclua";
            this.btnExclua.Size = new System.Drawing.Size(142, 70);
            this.btnExclua.TabIndex = 3;
            this.btnExclua.Text = "Excluir";
            this.btnExclua.UseVisualStyleBackColor = true;
            this.btnExclua.Click += new System.EventHandler(this.btnExclua_Click);
            // 
            // lblInserir
            // 
            this.lblInserir.AutoSize = true;
            this.lblInserir.Location = new System.Drawing.Point(252, 85);
            this.lblInserir.Name = "lblInserir";
            this.lblInserir.Size = new System.Drawing.Size(208, 13);
            this.lblInserir.TabIndex = 2;
            this.lblInserir.Text = "Exclua o aluno Otávio e imprima os demais";
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.Location = new System.Drawing.Point(133, 60);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(460, 13);
            this.lblInfo.TabIndex = 1;
            this.lblInfo.Text = "{\"Ana\", \"André\", \"Débora\", \"Fátima\", \"João\", \"Janete\", \"Otávio\", \"Marcelo\", \"Pedr" +
    "o\", \"Thais\"}";
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(840, 323);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.lblInserir);
            this.Controls.Add(this.btnExclua);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExclua;
        private System.Windows.Forms.Label lblInserir;
        private System.Windows.Forms.Label lblInfo;
    }
}