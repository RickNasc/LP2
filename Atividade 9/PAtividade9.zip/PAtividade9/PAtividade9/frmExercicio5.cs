﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade9
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnEntrada_Click(object sender, EventArgs e)
        {
            string auxiliar1;
            string auxiliar2;
            double[,] matriz1 = new double[20,3];
            double[] vetor2 = new double[20];

            vetor2[0] = 0;

            for (var l = 0; l < 20; l++)
                for (var c = 0; c < 3; c++)//Faz primeiro, (0,0) (0,1) (0,2)
                {
                    auxiliar1 = Interaction.InputBox("Digite as notas do aluno(a) "+(l + 1)+" nota "+(c + 1), "Entrada de Dados");
                    if (!double.TryParse(auxiliar1, out matriz1[l, c]))
                    {
                        MessageBox.Show("Valor inválido");
                        c = c - 1;
                    }
                    else
                    {
                        if (c == -1)
                        {
                            c = 0;
                            vetor2[l] = vetor2[l] + matriz1[l, c];// Variável acumuladora
                        }
                        else
                        {
                            c = c + 0;//não muda
                            vetor2[l] = vetor2[l] + matriz1[l, c];// Variável acumuladora
                        }
                    }
                }
            auxiliar1 = "";
            auxiliar2 = "";

            for (int l = 0; l < 20; l++)
            {
                vetor2[l] = vetor2[l] / 3;// Média
            }    

            foreach (double i in matriz1)
                auxiliar1 = auxiliar1 + "\n" + i;
            foreach (double i in vetor2)
                auxiliar2 = auxiliar2 + "\n" + i;

            MessageBox.Show(auxiliar2,"Médias");
        }
    }
}
