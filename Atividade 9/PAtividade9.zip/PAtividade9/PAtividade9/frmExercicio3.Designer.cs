﻿namespace PAtividade9
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalcularQtdeLet = new System.Windows.Forms.Button();
            this.lblInserir = new System.Windows.Forms.Label();
            this.lblInfo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCalcularQtdeLet
            // 
            this.btnCalcularQtdeLet.Location = new System.Drawing.Point(230, 113);
            this.btnCalcularQtdeLet.Name = "btnCalcularQtdeLet";
            this.btnCalcularQtdeLet.Size = new System.Drawing.Size(149, 77);
            this.btnCalcularQtdeLet.TabIndex = 3;
            this.btnCalcularQtdeLet.Text = "Calcular ";
            this.btnCalcularQtdeLet.UseVisualStyleBackColor = true;
            this.btnCalcularQtdeLet.Click += new System.EventHandler(this.btnCalcularQtdeLet_Click);
            // 
            // lblInserir
            // 
            this.lblInserir.AutoSize = true;
            this.lblInserir.Location = new System.Drawing.Point(187, 78);
            this.lblInserir.Name = "lblInserir";
            this.lblInserir.Size = new System.Drawing.Size(237, 13);
            this.lblInserir.TabIndex = 2;
            this.lblInserir.Text = "Ao final do laço, podemos afirmar que Total vale:";
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.Location = new System.Drawing.Point(100, 43);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(428, 13);
            this.lblInfo.TabIndex = 1;
            this.lblInfo.Text = "{\"Viviane\", \"André\", \"Hélio\", \"Denise\", \"Junior\",\"Leonardo\", \"Jose\", \"Nelma\", \"To" +
    "bby\"};";
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(663, 308);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.lblInserir);
            this.Controls.Add(this.btnCalcularQtdeLet);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCalcularQtdeLet;
        private System.Windows.Forms.Label lblInserir;
        private System.Windows.Forms.Label lblInfo;
    }
}