﻿namespace PFerramenta
{
    partial class frmMain
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.stpMenu01 = new System.Windows.Forms.MenuStrip();
            this.cadastroDeFerramentadsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sobreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stpMenu01.SuspendLayout();
            this.SuspendLayout();
            // 
            // stpMenu01
            // 
            this.stpMenu01.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.stpMenu01.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cadastroDeFerramentadsToolStripMenuItem,
            this.sobreToolStripMenuItem,
            this.sairToolStripMenuItem});
            this.stpMenu01.Location = new System.Drawing.Point(0, 0);
            this.stpMenu01.Name = "stpMenu01";
            this.stpMenu01.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.stpMenu01.Size = new System.Drawing.Size(1016, 33);
            this.stpMenu01.TabIndex = 0;
            this.stpMenu01.Text = "menuStrip1";
            // 
            // cadastroDeFerramentadsToolStripMenuItem
            // 
            this.cadastroDeFerramentadsToolStripMenuItem.Name = "cadastroDeFerramentadsToolStripMenuItem";
            this.cadastroDeFerramentadsToolStripMenuItem.Size = new System.Drawing.Size(222, 29);
            this.cadastroDeFerramentadsToolStripMenuItem.Text = "Cadastro de Ferramentas";
            this.cadastroDeFerramentadsToolStripMenuItem.Click += new System.EventHandler(this.cadastroDeFerramentadsToolStripMenuItem_Click);
            // 
            // sobreToolStripMenuItem
            // 
            this.sobreToolStripMenuItem.Name = "sobreToolStripMenuItem";
            this.sobreToolStripMenuItem.Size = new System.Drawing.Size(71, 29);
            this.sobreToolStripMenuItem.Text = "Sobre";
            this.sobreToolStripMenuItem.Click += new System.EventHandler(this.sobreToolStripMenuItem_Click);
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(53, 29);
            this.sairToolStripMenuItem.Text = "Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1016, 671);
            this.Controls.Add(this.stpMenu01);
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frm Main";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.stpMenu01.ResumeLayout(false);
            this.stpMenu01.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip stpMenu01;
        private System.Windows.Forms.ToolStripMenuItem cadastroDeFerramentadsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sobreToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
    }
}

