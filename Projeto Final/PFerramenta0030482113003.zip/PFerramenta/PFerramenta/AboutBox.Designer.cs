﻿namespace PFerramenta
{
    partial class frmAbBox
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tblLayout = new System.Windows.Forms.TableLayoutPanel();
            this.lblNomeProd = new System.Windows.Forms.Label();
            this.lvlVersão = new System.Windows.Forms.Label();
            this.lblCpright = new System.Windows.Forms.Label();
            this.lblNomeComp = new System.Windows.Forms.Label();
            this.txtDescri = new System.Windows.Forms.TextBox();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.tblLayout.SuspendLayout();
            this.SuspendLayout();
            // 
            // tblLayout
            // 
            this.tblLayout.BackColor = System.Drawing.Color.PowderBlue;
            this.tblLayout.ColumnCount = 1;
            this.tblLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblLayout.Controls.Add(this.lblNomeProd, 0, 0);
            this.tblLayout.Controls.Add(this.lvlVersão, 0, 1);
            this.tblLayout.Controls.Add(this.lblCpright, 0, 2);
            this.tblLayout.Controls.Add(this.lblNomeComp, 0, 3);
            this.tblLayout.Controls.Add(this.txtDescri, 0, 4);
            this.tblLayout.Controls.Add(this.btnConfirm, 0, 5);
            this.tblLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblLayout.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.tblLayout.Location = new System.Drawing.Point(18, 17);
            this.tblLayout.Margin = new System.Windows.Forms.Padding(6);
            this.tblLayout.Name = "tblLayout";
            this.tblLayout.RowCount = 6;
            this.tblLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tblLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tblLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tblLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tblLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tblLayout.Size = new System.Drawing.Size(682, 383);
            this.tblLayout.TabIndex = 0;
            // 
            // lblNomeProd
            // 
            this.lblNomeProd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNomeProd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeProd.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.lblNomeProd.Location = new System.Drawing.Point(12, 0);
            this.lblNomeProd.Margin = new System.Windows.Forms.Padding(12, 0, 6, 0);
            this.lblNomeProd.MaximumSize = new System.Drawing.Size(0, 33);
            this.lblNomeProd.Name = "lblNomeProd";
            this.lblNomeProd.Size = new System.Drawing.Size(664, 33);
            this.lblNomeProd.TabIndex = 19;
            this.lblNomeProd.Text = "Nome do Produto";
            this.lblNomeProd.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lvlVersão
            // 
            this.lvlVersão.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvlVersão.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvlVersão.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.lvlVersão.Location = new System.Drawing.Point(12, 38);
            this.lvlVersão.Margin = new System.Windows.Forms.Padding(12, 0, 6, 0);
            this.lvlVersão.MaximumSize = new System.Drawing.Size(0, 33);
            this.lvlVersão.Name = "lvlVersão";
            this.lvlVersão.Size = new System.Drawing.Size(664, 33);
            this.lvlVersão.TabIndex = 0;
            this.lvlVersão.Text = "Versão";
            this.lvlVersão.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblCpright
            // 
            this.lblCpright.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCpright.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCpright.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.lblCpright.Location = new System.Drawing.Point(12, 76);
            this.lblCpright.Margin = new System.Windows.Forms.Padding(12, 0, 6, 0);
            this.lblCpright.MaximumSize = new System.Drawing.Size(0, 33);
            this.lblCpright.Name = "lblCpright";
            this.lblCpright.Size = new System.Drawing.Size(664, 33);
            this.lblCpright.TabIndex = 21;
            this.lblCpright.Text = "Copyright";
            this.lblCpright.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNomeComp
            // 
            this.lblNomeComp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNomeComp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeComp.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.lblNomeComp.Location = new System.Drawing.Point(12, 114);
            this.lblNomeComp.Margin = new System.Windows.Forms.Padding(12, 0, 6, 0);
            this.lblNomeComp.MaximumSize = new System.Drawing.Size(0, 33);
            this.lblNomeComp.Name = "lblNomeComp";
            this.lblNomeComp.Size = new System.Drawing.Size(664, 33);
            this.lblNomeComp.TabIndex = 22;
            this.lblNomeComp.Text = "Nome da Companhia";
            this.lblNomeComp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtDescri
            // 
            this.txtDescri.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDescri.Location = new System.Drawing.Point(12, 158);
            this.txtDescri.Margin = new System.Windows.Forms.Padding(12, 6, 6, 6);
            this.txtDescri.Multiline = true;
            this.txtDescri.Name = "txtDescri";
            this.txtDescri.ReadOnly = true;
            this.txtDescri.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtDescri.Size = new System.Drawing.Size(664, 179);
            this.txtDescri.TabIndex = 23;
            this.txtDescri.TabStop = false;
            this.txtDescri.Text = "Descrição";
            // 
            // btnConfirm
            // 
            this.btnConfirm.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnConfirm.BackColor = System.Drawing.Color.Gainsboro;
            this.btnConfirm.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnConfirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirm.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnConfirm.Location = new System.Drawing.Point(266, 349);
            this.btnConfirm.Margin = new System.Windows.Forms.Padding(6);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(150, 28);
            this.btnConfirm.TabIndex = 24;
            this.btnConfirm.Text = "&OK";
            this.btnConfirm.UseVisualStyleBackColor = false;
            // 
            // frmAbBox
            // 
            this.AcceptButton = this.btnConfirm;
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(718, 417);
            this.Controls.Add(this.tblLayout);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Red;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAbBox";
            this.Padding = new System.Windows.Forms.Padding(18, 17, 18, 17);
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "frm AboutBox";
            this.tblLayout.ResumeLayout(false);
            this.tblLayout.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tblLayout;
        private System.Windows.Forms.Label lblNomeProd;
        private System.Windows.Forms.Label lvlVersão;
        private System.Windows.Forms.Label lblCpright;
        private System.Windows.Forms.Label lblNomeComp;
        private System.Windows.Forms.TextBox txtDescri;
        private System.Windows.Forms.Button btnConfirm;
    }
}
